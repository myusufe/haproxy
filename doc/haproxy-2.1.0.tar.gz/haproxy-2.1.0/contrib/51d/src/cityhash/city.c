typedef struct cityhash_t {
    // This is an empty structure to ensure a city.o is generated
    // by the dummy library, it is never used.
} dummyCityHash;